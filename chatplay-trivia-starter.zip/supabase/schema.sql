-- ChatPlay Trivia: secure MVP schema for Supabase
-- Run this in Supabase SQL Editor. It replaces the earlier prototype tables/policies.
-- If your earlier tables contain data you need, back them up before running this script.

create extension if not exists pgcrypto;

drop view if exists public.public_questions;
drop table if exists public.answers cascade;
drop table if exists public.players cascade;
drop table if exists public.game_rooms cascade;
drop table if exists public.questions cascade;

create table public.questions (
  id uuid primary key default gen_random_uuid(),
  question_text text not null,
  option_a text not null,
  option_b text not null,
  option_c text not null,
  option_d text not null,
  correct_option text not null check (correct_option in ('A','B','C','D')),
  difficulty text not null default 'mixed',
  active boolean not null default true
);

create table public.game_rooms (
  id uuid primary key default gen_random_uuid(),
  room_code text unique not null,
  host_player_id uuid,
  status text not null default 'waiting' check (status in ('waiting','playing','finished')),
  current_question integer not null default 0,
  question_count integer not null default 10,
  seconds_per_question integer not null default 20,
  question_started_at timestamptz,
  question_ids uuid[] not null default '{}',
  created_at timestamptz not null default now()
);

create table public.players (
  id uuid primary key default gen_random_uuid(),
  room_id uuid not null references public.game_rooms(id) on delete cascade,
  nickname text not null,
  score integer not null default 0,
  is_host boolean not null default false,
  joined_at timestamptz not null default now(),
  unique(room_id, nickname)
);

alter table public.game_rooms add constraint game_rooms_host_fk
  foreign key (host_player_id) references public.players(id) deferrable initially deferred;

create table public.answers (
  id uuid primary key default gen_random_uuid(),
  room_id uuid not null references public.game_rooms(id) on delete cascade,
  player_id uuid not null references public.players(id) on delete cascade,
  question_id uuid not null references public.questions(id),
  answer text not null check (answer in ('A','B','C','D')),
  is_correct boolean not null,
  created_at timestamptz not null default now(),
  unique(player_id, question_id)
);

alter table public.game_rooms enable row level security;
alter table public.players enable row level security;
alter table public.questions enable row level security;
alter table public.answers enable row level security;

-- Publicly readable lobby and score information only. No direct writes from browser.
create policy "rooms readable" on public.game_rooms for select to anon, authenticated using (true);
create policy "players readable" on public.players for select to anon, authenticated using (true);
create policy "questions hidden" on public.questions for select to anon, authenticated using (false);
create policy "answers hidden" on public.answers for select to anon, authenticated using (false);

grant select on public.game_rooms, public.players to anon, authenticated;
revoke all on public.questions, public.answers from anon, authenticated;

create or replace function public.create_game_room(p_nickname text, p_question_count integer default 10, p_seconds_per_question integer default 20)
returns table(room_id uuid, room_code text, player_id uuid)
language plpgsql security definer set search_path = public as $$
declare v_room uuid; v_code text; v_player uuid; v_ids uuid[];
begin
  if length(trim(p_nickname)) < 1 or length(trim(p_nickname)) > 18 then raise exception 'Nickname must be 1–18 characters'; end if;
  if p_question_count < 1 or p_question_count > 20 then raise exception 'Question count must be 1–20'; end if;
  if p_seconds_per_question not between 10 and 60 then raise exception 'Timer must be 10–60 seconds'; end if;
  select array_agg(id order by random()) into v_ids from (select id from questions where active limit p_question_count) q;
  if coalesce(array_length(v_ids,1),0) < p_question_count then raise exception 'Not enough active questions have been added yet'; end if;
  loop
    v_code := upper(substr(encode(gen_random_bytes(5),'hex'),1,6));
    exit when not exists(select 1 from game_rooms where game_rooms.room_code=v_code);
  end loop;
  insert into game_rooms(room_code,question_count,seconds_per_question,question_ids)
  values(v_code,p_question_count,p_seconds_per_question,v_ids) returning id into v_room;
  insert into players(room_id,nickname,is_host) values(v_room,trim(p_nickname),true) returning id into v_player;
  update game_rooms set host_player_id=v_player where id=v_room;
  return query select v_room,v_code,v_player;
end $$;

create or replace function public.join_game_room(p_room_code text, p_nickname text)
returns table(room_id uuid, player_id uuid)
language plpgsql security definer set search_path = public as $$
declare v_room uuid; v_player uuid; v_status text; v_count integer;
begin
  if length(trim(p_nickname)) < 1 or length(trim(p_nickname)) > 18 then raise exception 'Nickname must be 1–18 characters'; end if;
  select id,status into v_room,v_status from game_rooms where room_code=upper(trim(p_room_code));
  if v_room is null then raise exception 'Room code not found'; end if;
  if v_status <> 'waiting' then raise exception 'This game has already started'; end if;
  select count(*) into v_count from players where players.room_id=v_room;
  if v_count >= 10 then raise exception 'This room is full (10 players maximum)'; end if;
  insert into players(room_id,nickname) values(v_room,trim(p_nickname)) returning id into v_player;
  return query select v_room,v_player;
exception when unique_violation then raise exception 'That nickname is already taken in this room'; end $$;

create or replace function public.start_game(p_room_code text, p_player_id uuid)
returns boolean language plpgsql security definer set search_path = public as $$
declare r game_rooms%rowtype;
begin
  select * into r from game_rooms where room_code=upper(trim(p_room_code)) for update;
  if r.id is null then raise exception 'Room not found'; end if;
  if r.host_player_id <> p_player_id then raise exception 'Only the host can start the game'; end if;
  if r.status <> 'waiting' then raise exception 'Game has already started'; end if;
  update game_rooms set status='playing',current_question=1,question_started_at=now() where id=r.id;
  return true;
end $$;

create or replace function public.get_current_question(p_room_code text)
returns table(id uuid, question_text text, options text[])
language plpgsql security definer set search_path = public as $$
declare r game_rooms%rowtype; q questions%rowtype;
begin
  select * into r from game_rooms where room_code=upper(trim(p_room_code));
  if r.id is null or r.status <> 'playing' or r.current_question < 1 then return; end if;
  select * into q from questions where questions.id=r.question_ids[r.current_question];
  if q.id is null then return; end if;
  return query select q.id,q.question_text,array[q.option_a,q.option_b,q.option_c,q.option_d];
end $$;

create or replace function public.submit_game_answer(p_room_code text,p_player_id uuid,p_question_id uuid,p_answer text)
returns table(is_correct boolean, points_awarded integer)
language plpgsql security definer set search_path = public as $$
declare r game_rooms%rowtype; q questions%rowtype; v_correct boolean; v_points integer:=0;
begin
  select * into r from game_rooms where room_code=upper(trim(p_room_code)) for update;
  if r.id is null or r.status <> 'playing' then raise exception 'Game is not accepting answers'; end if;
  if not exists(select 1 from players where id=p_player_id and room_id=r.id) then raise exception 'Player is not in this room'; end if;
  if now() > r.question_started_at + make_interval(secs=>r.seconds_per_question) then raise exception 'Time is up'; end if;
  if p_question_id <> r.question_ids[r.current_question] then raise exception 'This question is no longer active'; end if;
  select * into q from questions where id=p_question_id;
  v_correct := upper(p_answer)=q.correct_option;
  if v_correct then v_points:=10; end if;
  insert into answers(room_id,player_id,question_id,answer,is_correct) values(r.id,p_player_id,p_question_id,upper(p_answer),v_correct);
  if v_correct then update players set score=score+v_points where id=p_player_id; end if;
  return query select v_correct,v_points;
exception when unique_violation then raise exception 'You have already answered this question'; end $$;

create or replace function public.advance_game_question(p_room_code text,p_player_id uuid)
returns boolean language plpgsql security definer set search_path = public as $$
declare r game_rooms%rowtype;
begin
  select * into r from game_rooms where room_code=upper(trim(p_room_code)) for update;
  if r.id is null then raise exception 'Room not found'; end if;
  if r.host_player_id <> p_player_id then raise exception 'Only the host can advance the game'; end if;
  if r.status <> 'playing' then raise exception 'Game is not active'; end if;
  if r.current_question >= r.question_count then update game_rooms set status='finished' where id=r.id;
  else update game_rooms set current_question=current_question+1,question_started_at=now() where id=r.id; end if;
  return true;
end $$;

revoke all on function public.create_game_room(text,integer,integer) from public;
revoke all on function public.join_game_room(text,text) from public;
revoke all on function public.start_game(text,uuid) from public;
revoke all on function public.get_current_question(text) from public;
revoke all on function public.submit_game_answer(text,uuid,uuid,text) from public;
revoke all on function public.advance_game_question(text,uuid) from public;
grant execute on function public.create_game_room(text,integer,integer) to anon, authenticated;
grant execute on function public.join_game_room(text,text) to anon, authenticated;
grant execute on function public.start_game(text,uuid) to anon, authenticated;
grant execute on function public.get_current_question(text) to anon, authenticated;
grant execute on function public.submit_game_answer(text,uuid,uuid,text) to anon, authenticated;
grant execute on function public.advance_game_question(text,uuid) to anon, authenticated;

-- Realtime updates power the lobby and live scoreboard.
alter publication supabase_realtime add table public.game_rooms;
alter publication supabase_realtime add table public.players;

insert into public.questions(question_text,option_a,option_b,option_c,option_d,correct_option,difficulty) values
('What is the capital of Nigeria?','Kano','Abuja','Lagos','Kaduna','B','easy'),
('Which planet is known as the Red Planet?','Venus','Jupiter','Mars','Mercury','C','easy'),
('How many sides does a hexagon have?','Five','Six','Seven','Eight','B','easy'),
('Which ocean is the largest?','Atlantic','Indian','Arctic','Pacific','D','easy'),
('Who wrote Things Fall Apart?','Wole Soyinka','Chinua Achebe','Buchi Emecheta','Chimamanda Adichie','B','medium'),
('What is the chemical symbol for gold?','Ag','Gd','Au','Go','C','medium'),
('Which gas do plants absorb from the atmosphere?','Oxygen','Carbon dioxide','Nitrogen','Hydrogen','B','medium'),
('In which year did Nigeria gain independence?','1957','1960','1963','1966','B','easy'),
('What is the square root of 144?','10','11','12','14','C','medium'),
('Which continent is the Sahara Desert located in?','Asia','Africa','Australia','South America','B','easy');
